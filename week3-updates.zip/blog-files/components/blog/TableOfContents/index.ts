export { TableOfContents } from './TableOfContents';
export type { Heading } from './TableOfContents';
